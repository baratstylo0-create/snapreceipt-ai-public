'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { convertCurrency, _resetCache, normalizeCurrencyCode } = require('../lib/currency');

// Stub global.fetch so tests never hit the real FX API. Returns a Frankfurter-shaped body.
function stubFetch(ratesByTo, { fail = false } = {}) {
  let calls = 0;
  global.fetch = async () => {
    calls++;
    if (fail) throw new Error('network down');
    return { text: async () => JSON.stringify({ amount: 1, base: 'X', date: '2026-06-12', rates: ratesByTo }) };
  };
  return () => calls;
}
const realFetch = global.fetch;
function restore() { global.fetch = realFetch; }

test('same currency → rate 1, no API call', async () => {
  _resetCache();
  const getCalls = stubFetch({});
  try {
    const r = await convertCurrency(100, 'USD', 'USD');
    assert.deepStrictEqual(r, { amount: 100, rate: 1, from: 'USD', to: 'USD', ok: true });
    assert.strictEqual(getCalls(), 0, 'must not call the FX API for same currency');
  } finally { restore(); }
});

test('converts using the fetched rate and rounds to 2dp', async () => {
  _resetCache();
  stubFetch({ MYR: 4.5 });
  try {
    const r = await convertCurrency(10, 'usd', 'myr'); // case-insensitive
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.rate, 4.5);
    assert.strictEqual(r.amount, 45); // 10 * 4.5
    assert.strictEqual(r.from, 'USD');
    assert.strictEqual(r.to, 'MYR');
  } finally { restore(); }
});

test('caches the rate — second call does not re-fetch', async () => {
  _resetCache();
  const getCalls = stubFetch({ EUR: 0.9 });
  try {
    await convertCurrency(10, 'USD', 'EUR');
    await convertCurrency(20, 'USD', 'EUR');
    assert.strictEqual(getCalls(), 1, 'rate should be cached after the first fetch');
  } finally { restore(); }
});

test('API failure → keeps original amount, ok:false (never guesses a rate)', async () => {
  _resetCache();
  stubFetch({}, { fail: true });
  try {
    const r = await convertCurrency(10, 'USD', 'MYR');
    assert.strictEqual(r.ok, false);
    assert.strictEqual(r.amount, 10, 'original amount preserved on failure');
    assert.strictEqual(r.rate, null);
    assert.strictEqual(r.reason, 'fx_unavailable');
  } finally { restore(); }
});

test('invalid currency code → ok:false (rounded), no API call', async () => {
  _resetCache();
  const getCalls = stubFetch({ MYR: 4.5 });
  try {
    const r = await convertCurrency(10.005, 'US', 'MYR'); // "US" is not a 3-letter code
    assert.strictEqual(r.ok, false);
    assert.strictEqual(r.reason, 'invalid_currency');
    assert.strictEqual(r.amount, 10.01); // fail-safe amount is rounded (M2)
    assert.strictEqual(getCalls(), 0);
  } finally { restore(); }
});

test('negative amount (refund) converts correctly', async () => {
  _resetCache();
  stubFetch({ MYR: 4.5 });
  try {
    const r = await convertCurrency(-20, 'USD', 'MYR');
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.amount, -90); // -20 * 4.5
  } finally { restore(); }
});

test('zero amount converts to zero (no divide-by-zero, still ok)', async () => {
  _resetCache();
  stubFetch({ MYR: 4.5 });
  try {
    const r = await convertCurrency(0, 'USD', 'MYR');
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.amount, 0);
  } finally { restore(); }
});

test('unknown but valid-format code (Frankfurter has no rate) → ok:false, fails safe', async () => {
  _resetCache();
  stubFetch({}); // response has no rates[to] → _fetchRate throws
  try {
    const r = await convertCurrency(10, 'USD', 'XYZ');
    assert.strictEqual(r.ok, false);
    assert.strictEqual(r.amount, 10); // original preserved
    assert.strictEqual(r.rate, null);
  } finally { restore(); }
});

// --- normalizeCurrencyCode (issue #45: OCR often extracts a symbol/abbreviation like
// "RM" for Malaysian Ringgit instead of an ISO-4217 code; assembleExpense's raw
// /^[A-Za-z]{3}$/ check rejects it and silently falls back to DEFAULT_CURRENCY,
// so the conversion never happens. This normalizer runs BEFORE that check.) ---

test('normalizeCurrencyCode: already a valid 3-letter ISO code passes through uppercased', () => {
  assert.strictEqual(normalizeCurrencyCode('usd'), 'USD');
  assert.strictEqual(normalizeCurrencyCode('MYR'), 'MYR');
});

test('normalizeCurrencyCode: known unambiguous symbols/abbreviations map to ISO', () => {
  assert.strictEqual(normalizeCurrencyCode('RM'), 'MYR');
  assert.strictEqual(normalizeCurrencyCode('rm'), 'MYR');
  assert.strictEqual(normalizeCurrencyCode('€'), 'EUR');
  assert.strictEqual(normalizeCurrencyCode('£'), 'GBP');
  assert.strictEqual(normalizeCurrencyCode('₹'), 'INR');
  assert.strictEqual(normalizeCurrencyCode('Rp'), 'IDR');
  assert.strictEqual(normalizeCurrencyCode('₩'), 'KRW');
  assert.strictEqual(normalizeCurrencyCode('₱'), 'PHP');
  assert.strictEqual(normalizeCurrencyCode('฿'), 'THB');
  assert.strictEqual(normalizeCurrencyCode('₫'), 'VND');
});

test('normalizeCurrencyCode: genuinely ambiguous symbols are NOT guessed (return null)', () => {
  // Bare "$" and "kr" are shared by many currencies (USD/SGD/AUD/CAD/HKD/MYR-"RM" aside;
  // SEK/NOK/DKK) — guessing wrong would silently misconvert money, worse than falling
  // back to DEFAULT_CURRENCY. Only unambiguous symbols get an alias.
  assert.strictEqual(normalizeCurrencyCode('$'), null);
  assert.strictEqual(normalizeCurrencyCode('kr'), null);
});

test('normalizeCurrencyCode: junk/empty/non-string input returns null, never throws', () => {
  assert.strictEqual(normalizeCurrencyCode(''), null);
  assert.strictEqual(normalizeCurrencyCode(null), null);
  assert.strictEqual(normalizeCurrencyCode(undefined), null);
  assert.strictEqual(normalizeCurrencyCode(42), null);
  assert.strictEqual(normalizeCurrencyCode('nonsense123'), null);
});
