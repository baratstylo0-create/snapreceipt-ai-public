'use strict';
const express = require('express');
const { checkDash, dashOrigin } = require('./expenses');
const { runBatch: realRunBatch } = require('../lib/massupload');
const ocr = require('../lib/ocr');
const templates = require('../lib/templates');
const pdf = require('../lib/pdf');
const { createRateLimiter } = require('../lib/ratelimit');

const MAX_IMAGES = Number(process.env.MASS_MAX_IMAGES) || 10;

// P6 abuse defense (§4.4): mass upload fans out to Groq vision OCR per image/page —
// cost-drainable without a limit. UPLOAD_RATE_MAX follows Barat's WEBHOOK_RATE_MAX naming
// convention (lib/ratelimit.js, wired into routes/webhook.js). Reuses the same shared
// limiter, no second implementation.
// Owner directive (lenient): this ceiling must NEVER trip a legit busy user/company — a
// human peaks at maybe 5-10 upload batches/min, so 120/min is ~10x headroom. It is a
// RUNAWAY backstop, not a throttle: the Groq key pool (ADR-016) is the cost backstop; this
// only caps a bug-loop / malicious flood before it hammers every pooled key indefinitely.
// Deliberately generous-but-present (not unlimited — a runaway drains the whole pool otherwise).
const uploadLimiter = createRateLimiter({ max: Number(process.env.UPLOAD_RATE_MAX) || 120 });

// #1 PDF: map lib/pdf's typed PdfError codes to an HTTP status + a FIXED client message.
// The message NEVER interpolates the code or any library internals (SOP §7.2). TOO_LARGE
// (byte cap OR the render-pixel-dimension cap) is a 413; every other reject is a 422.
const PDF_ERR_STATUS = { TOO_LARGE: 413, NOT_PDF: 422, CORRUPT: 422, ENCRYPTED: 422, EMPTY: 422 };
const PDF_ERR_MSG = {
  TOO_LARGE: 'a PDF was too large to process',
  NOT_PDF: 'a file was not a readable PDF',
  CORRUPT: 'a PDF could not be read',
  ENCRYPTED: 'a PDF is password-protected; please remove the password and resend',
  EMPTY: 'a PDF had no pages',
};

function isPdfBuffer(buf) {
  return buf.length >= 5 && buf.subarray(0, 5).toString('latin1') === '%PDF-';
}

// Strip a data-URI prefix ("data:image/png;base64,") if the client sent one.
function stripDataUri(s) {
  const m = /^data:[^;]*;base64,/.exec(s);
  return m ? s.slice(m[0].length) : s;
}

// #7 mass upload: failed[].reason from lib/massupload is RAW server-side error text
// (SOP §7.2 — client-facing responses must never leak internals like stack frames,
// file paths, or connection details). Rebuild each failed entry with a fixed,
// non-identifying message; log the raw reasons server-side for debugging.
function sanitizeSummary(summary) {
  const failed = (summary.failed || []).map(f => (
    'receipt_index' in f
      ? { image_index: f.image_index, receipt_index: f.receipt_index, reason: 'could not save receipt' }
      : { image_index: f.image_index, reason: 'could not read image' }
  ));
  return { ...summary, failed };
}

module.exports = function mountUpload(app, deps = {}) {
  const runBatch = deps.runBatch || realRunBatch;
  // Resolve via 'in deps' so a test can force the unavailable (503) path with an explicit undefined,
  // regardless of whether Barat's ocr.extractReceipts has merged yet. Resolution happens at mount
  // time (server boot), so the 503 lifts on the next restart after ocr.extractReceipts merges.
  const extractReceipts = ('extractReceipts' in deps) ? deps.extractReceipts : ocr.extractReceipts;
  const assembleExpense = ('assembleExpense' in deps) ? deps.assembleExpense : ocr.assembleExpense;
  const getFieldSpec = deps.getFieldSpec || templates.getFieldSpec;
  const rasterizePdf = deps.rasterizePdf || pdf.rasterizePdf;

  app.post('/api/upload', uploadLimiter, checkDash, express.json({ limit: '10mb' }), async (req, res) => {
    res.set('Access-Control-Allow-Origin', dashOrigin());
    try {
      const images = req.body && req.body.images;
      if (!Array.isArray(images) || images.length === 0 || images.some(s => typeof s !== 'string' || s === '')) {
        return res.status(400).json({ error: 'images must be a non-empty array of base64 strings' });
      }
      if (images.length > MAX_IMAGES) return res.status(413).json({ error: 'too many images (max ' + MAX_IMAGES + ')' });
      if (typeof extractReceipts !== 'function') return res.status(503).json({ error: 'mass upload not available yet' });

      const buffers = images.map(s => Buffer.from(stripDataUri(s), 'base64'));

      // Expand any PDF item into its rendered page images (a PDF page is just another
      // image for runBatch); non-PDF items pass straight through. rasterizePdf enforces
      // its own byte/page/pixel caps and throws a typed PdfError, which we map to a safe
      // 413/422 here. A PDF rejection fails the whole request (not a best-effort item)
      // so the client gets an actionable status.
      let pagesTruncated = false;
      let expanded;
      try {
        expanded = [];
        for (const buf of buffers) {
          if (isPdfBuffer(buf)) {
            const { pages, truncated } = await rasterizePdf(buf);
            if (truncated) pagesTruncated = true;
            for (const p of pages) expanded.push(p);
          } else {
            expanded.push(buf);
          }
        }
      } catch (e) {
        const code = e && e.code;
        if (code && PDF_ERR_STATUS[code]) return res.status(PDF_ERR_STATUS[code]).json({ error: PDF_ERR_MSG[code] });
        throw e; // not a PdfError → generic 502 via the outer catch (no internals leaked)
      }
      // Defensive: a batch of PDFs can expand past MAX_IMAGES pages — bound the Groq
      // call count (cost/DoS) and surface the truncation, same knob as the input cap.
      if (expanded.length > MAX_IMAGES) { expanded.length = MAX_IMAGES; pagesTruncated = true; }

      const fieldSpec = await getFieldSpec();
      const meta = { repName: 'Dashboard', fileId: null };
      const summary = await runBatch(expanded, fieldSpec, { extractReceipts, assembleExpense, meta });
      if (summary.failed && summary.failed.length) console.error('[api/upload] failures:', JSON.stringify(summary.failed));
      const out = sanitizeSummary(summary);
      if (pagesTruncated) out.pages_truncated = true;
      res.json(out);
    } catch (e) {
      console.error('[api/upload]', e && e.message);
      res.status(502).json({ error: 'upload failed' });
    }
  });
};
